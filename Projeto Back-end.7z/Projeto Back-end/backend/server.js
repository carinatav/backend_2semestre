const express = require("express");
const app = express();
const PORT = 3000;
app.use(express.json());
// 👇 Rota inicial — essa é a que mostra a mensagem
app.get("/", (req, res) => {
 res.send("🚀 Servidor rodando corretamente! Acesse /produtos para ver os dados.");
});
// 👇 Rota de produtos
app.get("/produtos", (req, res) => {
 res.json([
   { id: 1, nome: "Teclado", preco: 100 },
   { id: 2, nome: "Mouse", preco: 80 },
   { id: 3, nome: "Monitor", preco: 1200 }
 ]);
});
// 👇 Inicializa o servidor
app.listen(PORT, () => {
 console.log(`✅ Servidor rodando em http://localhost:${PORT}`);
});